import React from 'react';

export default function About() {
  return <div>
    salam
  </div>;
}

