import React, { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

export default function Home() {
  let { id } = useParams();
  debugger;
  console.log(id);
  const [dataval, setDataval] = useState();

  document.title = "تماس با ما";
  return (
    <div>
      <h1>Page 2</h1>
    </div>
  );
}
