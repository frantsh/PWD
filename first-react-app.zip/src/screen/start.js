import React from "react";
/* import { Link } from "react-router-dom"; */

export default function Start() {
  return (
    <>
      <div className="w-full h-screen flex items-center grow  bg-zinc-100  bg-[url('./logo1.png')]   bg-center bg-no-repeat">
        <div className="grid grid-row-2 m-auto">
          <h3 className="bg-clip-text   text-center text-3xl w-full mb-2">
            سلام،به تست استعدادیابی شریف استار خوش آمدید
          </h3>

          <p class="font-bold leading-8  text-center ">
            <br /> .فرم پیش رو برای ثبت نام در تور بازدید از فرایندهای"مرکز
            پردازش کالای دانش" دیجی کالا تهیه شده است
            <p class="font-bold leading-10 w-full">
              {" "}
              در صورت تمایل به شرکت در تور،مشخصات خودرا در این فرم کامل کنید{" "}
            </p>
          </p>
        </div>
      </div>
      {/* دوم */}
      <div className="w-full h-40 flex justify-center	 items-center m-auto align-item-center grow bg-[#DFDFDF] bg-cover bg-center bg-no-repeat">
        <a href="about-us">
          <button class="bg-[#6B9838] p-3 rounded-md text-white">
            شروع ازمون
          </button>
        </a>
      </div>
    </>
  );
}
